document.getElementById("playBtn").addEventListener("click", () => {
    alert("Lecture en cours 🎵");
});